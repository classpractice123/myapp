"use client"

import PDFViewer from "../src/components/PDFViewer/PDFViewer"

export default function SyntheticV0PageForDeployment() {
  return <PDFViewer />
}