import ForgotPasswordForm from "../components/Auth/ForgotPasswordForm"

const ForgotPassword = () => {
  return (
    <div className="forgot-password-page">
      <ForgotPasswordForm />
    </div>
  )
}

export default ForgotPassword

